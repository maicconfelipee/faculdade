package aula06_09_2019;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Banco {

	public static void main(String[] args) {
		Conta contas[] = new Conta[3];
		double valorDeposito;
		double valorSaque;

		//cadastrarContas(contas);
		cadastrarContas(contas);
	}



	public static void cadastrarContas(Conta contas[]) {
		int i, numeroAux;
		double saldoInicialAux;
		String titularAux;
		
		
		for(i=0; i<contas.length; i++) {
	
			do { 
				numeroAux = Integer.parseInt(JOptionPane.showInputDialog("Numero da conta? "));
			} while (verificarExistenciaDaConta(contas, numeroAux)!= null);

			titularAux = JOptionPane.showInputDialog("Titular da conta? ");
			saldoInicialAux = Double.parseDouble(JOptionPane.showInputDialog("Saldo inicial da conta? "));
			contas[i] = new Conta(numeroAux, titularAux, saldoInicialAux);
		}
		
	}

	public static Conta verificarExistenciaDaConta(Conta contas[], int codigoAux) {
		Conta encontrada;
		int i = 0;
		
		while (contas[i] != null && contas[i].numero != codigoAux) 
			i++;
		
		encontrada = contas[i];
		return encontrada;
	}
}
