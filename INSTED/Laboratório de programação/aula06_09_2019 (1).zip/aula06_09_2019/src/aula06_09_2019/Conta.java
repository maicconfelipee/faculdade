package aula06_09_2019;

import javax.swing.JOptionPane;

public class Conta {
	
	int numero;
	String titular;
	double saldo;
	
	
	Conta(int numero, String titular, double saldo  ) {
	   this.numero = numero;
	   this.titular = titular;
	   depositar(saldo);
		
	}
	
	void depositar(double valor) {
		this.saldo = this.saldo + valor;
	}
	

	void sacar(double valor) {
		if (valor <= this.saldo )
   		   this.saldo = this.saldo - valor;
		else
			JOptionPane.showMessageDialog(null,  "Saldo insuficiente para sacar R$ "+ valor + " reais");
	}

	
	
	

}
