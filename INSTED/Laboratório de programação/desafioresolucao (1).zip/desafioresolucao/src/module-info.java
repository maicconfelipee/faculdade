module desafioresolucao {
	requires java.desktop;
}