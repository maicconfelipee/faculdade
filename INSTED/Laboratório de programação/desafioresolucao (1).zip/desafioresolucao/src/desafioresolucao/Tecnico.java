package desafioresolucao;

import javax.swing.JOptionPane;

public class Tecnico extends Funcionario {
	int saldoDeGols;

	/**
	 * 
	 */
	public Tecnico() {
		super();
	}
	
	public Tecnico(int saldo) {
		super();
		System.out.println("no construtor o tecnico");
		this.saldoDeGols = saldo;
	}	
	
	
	public void reajustarSalario() {
		if (this.saldoDeGols > 0)
			super.salario = super.salario * 1.05;
		JOptionPane.showMessageDialog(null, "novo salario o técnico: " + this.salario);
	}
}
