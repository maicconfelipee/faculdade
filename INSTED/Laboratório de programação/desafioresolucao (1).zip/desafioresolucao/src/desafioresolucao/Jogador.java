package desafioresolucao;

import javax.swing.JOptionPane;

public class Jogador extends Funcionario {
	String posicao;
	int golsFeitos;
	/**
	 * 
	 */
	public Jogador() {
		super();
		this.posicao = JOptionPane.showInputDialog("Posicao do jogador: ");
		this.golsFeitos = Integer.parseInt(JOptionPane.showInputDialog("Total de gols feitos pelo jogador: "));
		
	}
	
	public void reajustarSalario() {
		if (this.golsFeitos > 5)
			super.salario = super.salario * 1.1;
		JOptionPane.showMessageDialog(null, "novo salario do jogador: " + this.salario);
	}

	
}
