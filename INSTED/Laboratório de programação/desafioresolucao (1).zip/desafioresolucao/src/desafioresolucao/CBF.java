package desafioresolucao;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class CBF {

	public static void main(String[] args) {
		Time t[] = new Time[2];
		
		for(int i=0; i<t.length; i++) {
			t[i] = new Time();
		//	t[i].nome = JOptionPane.showInputDialog("Nome do time? ");
			t[i].setNome(JOptionPane.showInputDialog("Nome do time? "));
			
		//	t[i].golsFeitos = Integer.parseInt(JOptionPane.showInputDialog("Total de gols feitos? "));
			t[i].setGolsFeitos(Integer.parseInt(JOptionPane.showInputDialog("Total de gols feitos? ")));
			
		//	t[i].golsTomados = Integer.parseInt(JOptionPane.showInputDialog("Total de gols tomados? "));
			t[i].setGolsTomados(Integer.parseInt(JOptionPane.showInputDialog("Total de gols tomados? ")));
			
		//	t[i].totalPontos = Integer.parseInt(JOptionPane.showInputDialog("Total de pontos? "));	
			t[i].setTotalPontos(Integer.parseInt(JOptionPane.showInputDialog("Total de pontos? ")));
			
			t[i].cadastrarFuncionarios();
		}
		
		for(int i=0; i<t.length; i++) {
		   t[i].reajustarSalarios();				
		}
		
		
		for(int i=0; i<t.length; i++) {
			   t[i].reajustarSalarios();				
			}
		
		String nomeDoSujeito = JOptionPane.showInputDialog("Nome do jaogador que vai receber aumento: ");
		for (int i=0; i< t.length; i++) {
			t[i].reajustarPorNome(nomeDoSujeito);
			
			
		}
		
/*		
		Mostrar times já cadastrados
*/		
		for(int i=0; i<t.length; i++) {
			JOptionPane.showMessageDialog(null, t[i].getNome());
			JOptionPane.showMessageDialog(null, t[i].getGolsFeitos());
			JOptionPane.showMessageDialog(null, t[i].getGolsTomados());
			JOptionPane.showMessageDialog(null, t[i].getTotalPontos());
			
			
			for(int j=0;j<t[i].func.length; j++) 
				t[i].func[j].reajustarSalario();
		}
		
		

	}

}
