package desafioresolucao;

public class Time {
	private String nome;
	private int golsFeitos;
	private int golsTomados;
	private int totalPontos;
	Funcionario func[]; 	//Lista de 12 funcionarios - naos sei fazer; pensar depois
	
	
	/**
	 * 
	 */
	public Time() {
		super();
		this.func = new Funcionario[2];
		
	}
	
	public void cadastrarFuncionarios() {
		System.out.println("no cadastro de funcionarios");
		this.func[0] = new Tecnico(this.golsFeitos - this.golsTomados);
		
		this.func[1] = new Jogador();
		
		
		
	}
	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return the golsFeitos
	 */
	public int getGolsFeitos() {
		return golsFeitos;
	}
	/**
	 * @param golsFeitos the golsFeitos to set
	 */
	public void setGolsFeitos(int golsFeitos) {
		this.golsFeitos = golsFeitos;
	}
	/**
	 * @return the golsTomados
	 */
	public int getGolsTomados() {
		return golsTomados;
	}
	/**
	 * @param golsTomados the golsTomados to set
	 */
	public void setGolsTomados(int golsTomados) {
		this.golsTomados = golsTomados;
	}
	/**
	 * @return the totalPontos
	 */
	public int getTotalPontos() {
		return totalPontos;
	}
	/**
	 * @param totalPontos the totalPontos to set
	 */
	public void setTotalPontos(int totalPontos) {
		this.totalPontos = totalPontos;
	}
	
	public void reajustarSalarios() {
		
		this.func[0].reajustarSalario();
		
		this.func[1].reajustarSalario();
		
	}
	
	public void reajustarPorNome(String nomeDoSujeito) {
		for (int i=0; i<this.func.length; i++) {
			this.func[i].reajustarPorNome(nomeDoSujeito);
			
			
		}
	}
	
}









