package desafioresolucao;

import javax.swing.JOptionPane;

public class Funcionario {
	
	String nome;
	double salario;
	String terminoContrato;
	/**
	 * 
	 */
	public Funcionario() {
		System.out.println("no construtor do funcionario");
		this.nome = JOptionPane.showInputDialog("Nome do funcionario: ");
		this.salario = Integer.parseInt(JOptionPane.showInputDialog("Salario do funcionario: "));
		this.terminoContrato = JOptionPane.showInputDialog("Data termino contrato do funcionario: ");	
	}	
	
	public void reajustarSalario() {
		
		
	}
	
	public void reajustarPorNome(String nomeDoSujeito) {
		if (this.nome.equalsIgnoreCase(nomeDoSujeito)) {
			this.salario = Double.parseDouble(JOptionPane.showInputDialog("Novo salario do " + this.nome + ": "));
		}
			
			
	}
	
	
	
	
}
