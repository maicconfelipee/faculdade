package controleescolar;

import javax.swing.JOptionPane;

public class Escola {
	
	Curso lista[] = new Curso[2];
	
	public void cadastrar() {
		for(int i=0; i<lista.length; i++) {		
			lista[i] = new Curso();
			boolean ehRepetido;
			do {
				lista[i].codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo do curso"));
				ehRepetido = false;
				for (int j=0; j<i; j++) {
					if (lista[i].codigo == lista[j].codigo)
						ehRepetido = true;
				}
				
				if (ehRepetido == true) {
					JOptionPane.showMessageDialog(null, "Codigo repetido.");
				}
				else {			
					lista[i].nome = JOptionPane.showInputDialog("Nome do curso");
					lista[i].duracao = Integer.parseInt(JOptionPane.showInputDialog("Duracao do curso em semestre"));
				}
			} while (ehRepetido);
		}
	}
	

}
