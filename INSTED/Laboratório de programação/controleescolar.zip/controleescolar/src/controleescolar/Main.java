package controleescolar;

import javax.swing.JOptionPane;

public class Main {
	static Escola insted;
	public static void main(String[] args) {
		insted = new Escola();
		
		int opcao;
			do {
				try {
					opcao = Integer.parseInt(JOptionPane.showInputDialog("Qual a opcao desejada? \n1- Cadastrar cursos \n2-Cadastrar disciplinas \n3- Sair"));
					
					switch(opcao) {
					case 1:
						insted.cadastrar();
						break;
					case 2:
						
						
					}
				}
				catch (Exception e) {
					JOptionPane.showMessageDialog(null, "So numeros, distraído!");
					opcao = 5;
					
				}
			
			} while (opcao != 3);
		

		
	}

}
