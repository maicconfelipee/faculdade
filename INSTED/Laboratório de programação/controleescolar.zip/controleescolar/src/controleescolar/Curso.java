package controleescolar;

public class Curso {
	int codigo;
	String nome;
	int duracao;
	

}
