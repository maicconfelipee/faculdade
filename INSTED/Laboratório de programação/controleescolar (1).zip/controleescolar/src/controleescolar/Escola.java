package controleescolar;

import javax.swing.JOptionPane;

public class Escola {
	
	Curso listaCurso[] = new Curso[2];
	Disciplina listaDisc[] = new Disciplina[5];
	
	public void cadastrarCursos() {
		for(int i=0; i<listaCurso.length; i++) {		
			listaCurso[i] = new Curso();
			boolean ehRepetido;
			do {
				listaCurso[i].codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo do curso"));
				ehRepetido = false;
				for (int j=0; j<i; j++) {
					if (listaCurso[i].codigo == listaCurso[j].codigo)
						ehRepetido = true;
				}
				
				if (ehRepetido == true) {
					JOptionPane.showMessageDialog(null, "Codigo repetido.");
				}
				else {			
					listaCurso[i].nome = JOptionPane.showInputDialog("Nome do curso");
					listaCurso[i].duracao = Integer.parseInt(JOptionPane.showInputDialog("Duracao do curso em semestre"));
				}
			} while (ehRepetido);
		}
	}
	
	public void cadastrarDisciplinas() {
		
		for(int i=0; i<listaDisc.length; i++) {		
			listaDisc[i] = new Disciplina();
			listaDisc[i].codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo da disciplina: "));
			listaDisc[i].nome = JOptionPane.showInputDialog("Nome da disciplina: ");
			listaDisc[i].cargaHoraria = Integer.parseInt(JOptionPane.showInputDialog("Carga horaria da disciplina: "));
		}
	}
	
	public Curso buscarCursoPorNome(String nomeCurso) {
		Curso encontrou = null;
		int j=0;
		while (j < listaCurso.length && !listaCurso[j].nome.equalsIgnoreCase(nomeCurso))
			j++;
		if(j < listaCurso.length)
			encontrou = listaCurso[j];
		return encontrou;
	}
	
	public Disciplina buscarDisciplinaPorNome(String nomeDisciplina) {
		Disciplina encontrou = null;
		int j=0;
		while (j < listaDisc.length && !listaDisc[j].nome.equalsIgnoreCase(nomeDisciplina))
			j++;
		if(j < listaDisc.length)
			encontrou = listaDisc[j];
		return encontrou;
	}
	
	public void montarMatrizCurricular(Curso curso) {
		String continuaCadastrando;
		do {
			String discAux = JOptionPane.showInputDialog("nome da disciplina? ");
			Disciplina disciplinaEncontrada = buscarDisciplinaPorNome(discAux);
			if (disciplinaEncontrada == null)
				JOptionPane.showMessageDialog(null, "Disciplina não cadastrada");
			else {
				//aqui deve verificar se a disciplina já não está cadastrada na matriz curricular do curso
				curso.disc.add(disciplinaEncontrada);
			}
			continuaCadastrando = JOptionPane.showInputDialog("Continuar cadastrando? Digite: Sim ou Não");
		} while (continuaCadastrando.equalsIgnoreCase("Sim"));	
	}
	
	public void visualizarMatrizCurricular(Curso curso) {
		String matriz = "Curso: " + curso.nome + "\nDisciplinas: ";
		for(int i=0; i<curso.disc.size(); i++) {		
			matriz = matriz + "\nCódigo: " + curso.disc.get(i).codigo + 
					" Nome: " + curso.disc.get(i).nome + 
					" carga horaria" + curso.disc.get(i).cargaHoraria;
		}
		JOptionPane.showMessageDialog(null, matriz);
	}
	
		
}
	