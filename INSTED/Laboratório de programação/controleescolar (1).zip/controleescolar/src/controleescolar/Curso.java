package controleescolar;

import java.util.ArrayList;

public class Curso {
	int codigo;
	String nome;
	int duracao;
	ArrayList<Disciplina> disc = new ArrayList<Disciplina>();
	/**
	 * @param codigo
	 * @param nome
	 * @param duracao
	 */
	public Curso(int codigo, String nome, int duracao) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.duracao = duracao;
		disc = null; //vai deixar de ser null quando for montada a matriz curricular do curso
	}
	
	public Curso() {
		super();

	}	
	
public String getNome() {
	return this.nome;
}
	
}
