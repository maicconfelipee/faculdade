package controleescolar;

public class Disciplina {
	int codigo;
	String nome;
	int cargaHoraria;
}
