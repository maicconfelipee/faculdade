package controleescolar;

import java.util.ArrayList;
import java.util.Comparator;

import javax.swing.JOptionPane;

public class Main {
	static Escola insted;
	public static void main(String[] args) {
		insted = new Escola();
		
		Curso cursoEncontrado;
		String nomeCurso;
		
		int opcao;
			do {
					opcao = Integer.parseInt(JOptionPane.showInputDialog("Qual a opcao desejada? "+
							"\n1- Cadastrar cursos "+
							"\n2- Cadastrar disciplinas "+
							"\n3- Montar matriz curricular" +
							"\n4- Mostrar matriz curricular" +
							"\n5- Sair"));
					
					switch(opcao) {
					case 1:
						insted.cadastrarCursos();
						break;
					case 2:
						insted.cadastrarDisciplinas();
						break;
					case 3:
						nomeCurso = JOptionPane.showInputDialog("Digite nome do curso para montagem da matriz curricular");
						cursoEncontrado = insted.buscarCursoPorNome(nomeCurso);
						if (cursoEncontrado != null)
							insted.montarMatrizCurricular(cursoEncontrado);
						else JOptionPane.showMessageDialog(null, "Curso não cadastrado");
						break;
					case 4:
						nomeCurso = JOptionPane.showInputDialog("Digite nome do curso para visualizar a matriz curricular");
						cursoEncontrado = insted.buscarCursoPorNome(nomeCurso);
						if (cursoEncontrado != null)
							insted.visualizarMatrizCurricular(cursoEncontrado);
						else JOptionPane.showMessageDialog(null, "Curso não cadastrado");
						break;						
						
					}
		
			} while (opcao != 5);
		
	}

}
