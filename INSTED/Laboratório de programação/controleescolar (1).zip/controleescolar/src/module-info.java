module controleescolar {
	requires java.desktop;
}