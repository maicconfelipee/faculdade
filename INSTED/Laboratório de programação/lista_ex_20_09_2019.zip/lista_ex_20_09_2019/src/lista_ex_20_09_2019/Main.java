package lista_ex_20_09_2019;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		int exercicioDesejado;

		do {
		exercicioDesejado = Integer.parseInt(JOptionPane.showInputDialog("\nEscolha o número do exercício. Para encerrar, digite 0: " ));
		switch (exercicioDesejado) {
		case 1:
			resolucaoExercicio1();
			break;
		case 2:
			resolucaoExercicio2();
			break;
		case 4:
			resolucaoExercicio4();
			break; 
		case 5:
			resolucaoExercicio5();
			break; 
		case 8:
			resolucaoExercicio8();
			break; 			
			
		}
		} while (exercicioDesejado != 0);
			
	}

	public static void resolucaoExercicio1() {
		double a;
		double b;
		double c;
		a = Double.parseDouble(JOptionPane.showInputDialog("Medida do lado a? "));
		b = Double.parseDouble(JOptionPane.showInputDialog("Medida do lado b? "));
		c = Double.parseDouble(JOptionPane.showInputDialog("Medida do lado c? "));		
		
		if (a <= b+c && b <= a+c && c <= a+b) {
			String msg = "É um triângulo ";
			if (a == b && b == c) 
				msg = msg + "equilátero";
			else if (a != b && a!=c && b!=c)
				    msg = msg + "escaleno";
				else
					msg = msg + "isosceles";
			JOptionPane.showMessageDialog(null, msg);
		}
		else
			JOptionPane.showMessageDialog(null, "As medidas dos lados não formam um triângulo");
	} //fim resolucaoExercicio1


	public static void resolucaoExercicio2() {
		int multiplicando;
		int multiplicador;
		int produto;

		for (multiplicando = 1; multiplicando <= 9; multiplicando ++) {
			System.out.println("\n---------------------");
			for (multiplicador = 0; multiplicador <= 10; multiplicador ++) {
				produto = multiplicando * multiplicador;
				System.out.println(multiplicando + " X " + multiplicador + " = " + produto);
			}
		}
	} //fim resolucaoExercicio2
	
	public static void resolucaoExercicio4() {
		String nomeOriginal;
		String nomeFormatado;
		nomeOriginal = JOptionPane.showInputDialog("Digite o nome completo:");
		
		String partes[] = nomeOriginal.split(" ");
		
		nomeFormatado = partes[partes.length -1];
		if (partes.length > 1) {
			nomeFormatado = nomeFormatado + ", ";
			for (int i= 0; i< partes.length -1 ; i++) {
				nomeFormatado = nomeFormatado + partes[i].charAt(0) + ". ";
			}
		}
		JOptionPane.showMessageDialog(null,  nomeFormatado);
	
	} //fim resolucaoExercicio4
	
	public static void resolucaoExercicio5() {
		String nomeMes[] = {"Janeiro","Fevereiro", "Março","Abril","Maio","Junho","Julho","Agosto","Setembro", "Outubro", "Novembro", "Dezembro"};				           
		double temperatura [] = new double[12];
		int i;
		int indiceAux;
		double maiorTemp;
		
		for(i=0;i<12;i++)
			temperatura[i] = Double.parseDouble(JOptionPane.showInputDialog("Temperatura média de " + nomeMes[i] + ": "));
			
		maiorTemp = temperatura[0];
		indiceAux = 0;
		for(i=1;i<12;i++) {
			if(temperatura[i] > maiorTemp) {
				maiorTemp = temperatura[i];
				indiceAux = i;
			}
		}
		JOptionPane.showMessageDialog(null,  "A maior temperatua foi " + maiorTemp + " graus e ocorreu em " + nomeMes[indiceAux]);	
	} //fim resolucaoExercicio5
	
	public static void resolucaoExercicio8() {
		int numeros[] = new int[10];
		int numerosAnalisados[] = new int[10];
		int aparicoes[] = new int[10];
		int contRepeticoes=0;
		int j;
		
		for(int i=0;i<10;i++) {
			numeros[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + i + "º número inteiro: "));
		}
		
		for(int i=0;i<10;i++) {
			j=0;
			while (j < contRepeticoes && numerosAnalisados[j] != numeros[i])
				j++;
			if (j == contRepeticoes) {
				numerosAnalisados[contRepeticoes]=numeros[i];
				aparicoes[contRepeticoes] = 1;
				contRepeticoes++;
			}
			else 
				aparicoes[j] = aparicoes[j]+1;
		}
		
		for(int i=0;i<contRepeticoes;i++) {
			if(aparicoes[i] > 1) {
				System.out.println("O numero " + numerosAnalisados[i] + " apareceu " + aparicoes[i] + " vezes");
			}
		}
	} //fim resolucaoExercicio8
	
}
