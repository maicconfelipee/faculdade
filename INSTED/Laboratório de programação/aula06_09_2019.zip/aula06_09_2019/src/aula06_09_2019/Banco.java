package aula06_09_2019;

import javax.swing.JOptionPane;

public class Banco {

	public static void main(String[] args) {
		Conta c;
		double valorDeposito;
		double valorSaque;
		
		c = new Conta(1, "Edilene", 100);
		JOptionPane.showMessageDialog(null, "Saldo inicial: " + c.saldo);
		
		valorDeposito = Double.parseDouble(JOptionPane.showInputDialog("Digite valor do deposito"));
		c.depositar(valorDeposito);
		JOptionPane.showMessageDialog(null, "Saldo após deposito: " + c.saldo);

		valorSaque = Double.parseDouble(JOptionPane.showInputDialog("Digite valor do saque"));
		c.sacar(valorSaque);
		JOptionPane.showMessageDialog(null, "Saldo após saque: " + c.saldo);
		
	}

}
