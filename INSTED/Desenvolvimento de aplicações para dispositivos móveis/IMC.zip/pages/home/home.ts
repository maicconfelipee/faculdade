import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  peso;
  altura;
  resultado;
  

  constructor(public navCtrl: NavController) {
  }
  calcularIMC() {
  var alturamt
   alturamt=this.altura/100
    this.resultado = (this.peso /(alturamt*alturamt)).toFixed(1);


   if (this.resultado <= 18.5) {
     this.resultado += (" Abaixo do peso");
    }
    if (this.resultado >= 18.6 && this.resultado <= 24.9){
      this.resultado +=(" Peso ideal");
    }
     if (this.resultado >= 25 && this.resultado <= 29.9){
      this.resultado +=(" Levemente acima do peso");
    }

     if (this.resultado >= 30 && this.resultado <= 34.9){
      this.resultado +=(" Obesidade grau I");
    
  }

    if (this.resultado >= 35 && this.resultado <= 39.9){
     this.resultado +=(" Obesidade grau II");
    }

     if (this.resultado >= 40){
      this.resultado +=(" Obesidade grau III");
    }
  }
}